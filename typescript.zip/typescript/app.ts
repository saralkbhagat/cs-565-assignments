import {puppy} from './puppy';

var hotdog = new puppy('Eduard');
console.log(hotdog.bark());

var oscar = new puppy('Oscar-Claude');
console.log(oscar.bark());