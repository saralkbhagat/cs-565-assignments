export class puppy {
    constructor(public name: string) {}
    bark() {
        return 'Gav! my name is ' + this.name;
    }
}