export class puppy {
    // this is a method
    bark() {
        return 'Gav gav!!' //what Russian dogs say, apparently
    }
}

var hotdog = new puppy();
console.log(hotdog.bark());