"use strict";
exports.__esModule = true;
var puppy_1 = require("./puppy");
var hotdog = new puppy_1.puppy('Eduard');
console.log(hotdog.bark());
var oscar = new puppy_1.puppy('Oscar-Claude');
console.log(oscar.bark());
